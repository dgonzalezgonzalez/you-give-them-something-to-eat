from pathlib import Path
import json,itertools,platform
from fractions import Fraction
import numpy as np,pandas as pd,scipy
R=Path(__file__).parent
p=pd.read_csv(R/'synthetic_pairs.csv');d=pd.read_csv(R/'synthetic_draws.csv');r=pd.read_csv(R/'synthetic_results.csv')
# Published effect-level pairs transcribed from frozen summary.json (GitHub response 39).
references={
 ('assignment_dependent',-160):(0.00026557703125,8.587638157380891e-06),
 ('assignment_dependent',0):(0.,0.),
 ('assignment_dependent',40):(1.8652083333333424e-06,3.3431323003950486e-06),
 ('assignment_dependent',160):(3.05501041666668e-05,1.9071555527363552e-05),
 ('coarse_interval',-160):(0.0042324818229166,2.718196639759331e-05),
 ('coarse_interval',0):(0.,0.),
 ('coarse_interval',40):(0.0002323268229166,5.872838872629242e-06),
 ('coarse_interval',160):(0.003845973125,2.5597357888430933e-05),
 ('complete',-160):(0.0031081015104166,6.57593109755502e-05),
 ('complete',0):(0.,0.),
 ('complete',40):(0.0023038690494791,2.2247638600843977e-05),
 ('complete',160):(0.0030591203125,7.25590674846272e-05)}
checks=[]
for (report,effect),(mean,se) in references.items():
 sub=p[(p.reporting==report)&(p.effect_thousandths==effect)&(p.first_method=='quota')&(p.second_method=='empirical_bernstein_fixed_forecast')]
 gotmean=sub.mean_regret_difference.mean();gotse=np.sqrt((sub.paired_mc_standard_error**2).sum())/len(sub)
 checks.append({'reporting':report,'effect':effect,'recomputed_mean':gotmean,'published_mean':mean,'recomputed_mc_se':gotse,'published_mc_se':se,'mean_error':abs(gotmean-mean),'se_error':abs(gotse-se)})
# 32 paired raw regret draws transcribed from frozen draws-000-0.json.
q=[.04964736,.0657672,.05199632,.06145328,.04313872,.03715024,.04772896,.04229056,.06594816,.03854288,.05009328,.05520368,.05564128,.0409808,.04274752,.04163632,.04404944,.05794288,.0492008,.05306944,.05917936,.05794288,.0545776,.0575088,.04727952,.05917936,.04385456,.04772896,.04404944,.05351008,.04708672,.03834432]
e=[.04711504,.06469104,.05223696,.06079536,.04304832,.03555808,.0460656,.04083696,.06392912,.03677488,.04896688,.0538176,.05293824,.04067376,.04165024,.03971168,.0425264,.05739568,.04772448,.05149712,.05673744,.05706736,.0539512,.0557192,.04659168,.05822736,.04371424,.04585136,.04379904,.05368464,.04602624,.03714096]
sub=d[(d['case']==0)&(d.repetition<32)]
rawerr=max(np.max(abs(sub.quota.to_numpy()-q)),np.max(abs(sub.empirical_bernstein_fixed_forecast.to_numpy()-e)))
assert rawerr<1e-14,rawerr
z=np.array(q)-np.array(e)
# Exact no-learning calculation, all effects equally weighted.
no_learning=sum(abs(Fraction(x,1000))/2 for x in [-160,0,40,160])/4
# Every selected loss is constructed from fixed actual outcomes, not field observations.
sm={
 'review_tag':'v0.8.0','review_commit':'50c96dcea50b5aac25e5beb0912f54ff26e1b47b',
 'scientific_source':'aa8667ccde0e00d4c5aa182a89d88b4065a6dda6',
 'runtime':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},
 'scope':'Independent floating reconstruction of the full declared synthetic catalogue (144 cells x256 assignments,seven rules); no field microdata/master/PDF execution. It does not replace directed certificates or exact per-draw author validators.',
 'effect_pairs_checked':checks,'maximum_effect_mean_error':max(x['mean_error'] for x in checks),'maximum_effect_se_error':max(x['se_error'] for x in checks),
 'published_draw_spotcheck':{'case':0,'repetitions':'0-31','methods':['quota','empirical_bernstein_fixed_forecast'],'maximum_error':float(rawerr),'paired_mean':z.mean(),'paired_mc_se':z.std(ddof=1)/np.sqrt(32)},
 'exact_no_learning_average':str(no_learning),
 'cost_reconstruction':json.loads((R/'cost_reconstruction.json').read_text()),
 'not_executed':['household or child microdata','other eight canonical input reconstructions','empirical moment/model regeneration','field population membership/dual replay','full master','Stata','author exact synthetic validators','manuscript PDF inspection/compilation','hosted artifact download/hash']}
(R/'summary.json').write_text(json.dumps(sm,indent=2))
print(json.dumps({k:v for k,v in sm.items() if k not in ['effect_pairs_checked','cost_reconstruction']},indent=2))
print(r[r.reporting=='assignment_dependent'].groupby(['effect_thousandths','method']).mean_actual_regret.mean().unstack().to_string())
print('Finite confidence rules certificate <=.10 selective reporting:',r[r.reporting=='assignment_dependent'].count_le_010.sum())
print('All scenario interval coverage:',r.coverage.min(),r.coverage.max(),'fallbacks',r.fallbacks.sum())
