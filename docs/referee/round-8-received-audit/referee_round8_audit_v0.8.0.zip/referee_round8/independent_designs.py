"""Independent floating reconstruction; no author imports, field data, or directed certificates."""
import itertools,json,math,time
from fractions import Fraction
from pathlib import Path
import numpy as np,pandas as pd
from scipy.optimize import minimize_scalar
ROOT=Path(__file__).parent;LOGCAP=math.log(80);R=256;SEED=20261001
METHODS=['quota','harmonic_martingale','weight_sensitive_product','weight_sensitive_hybrid','empirical_bernstein_fixed_forecast','no_learning_half','empirical_best_midpoint']
def harmonic(n,k):
 def f(j):return Fraction(n*n*(n-j)**2,j*j)*sum((Fraction(1,(n-t)**2) for t in range(1,j+1)),Fraction())
 return float(min(f(k),Fraction((n-k)**2,k*k)*f(n-k)))
def qlog(w,k,lam):
 n=len(w);w=np.sort(w)[::-1];assert 2*k==n
 pop=(np.arange(n)[None,:]<np.arange(n+1)[:,None])*w
 logs=lam*(n*pop-pop.sum(axis=1)[:,None])/k
 dp=np.full((n+1,k+1),-np.inf);dp[:,0]=0.
 for t in range(1,n+1):
  j=np.arange(1,min(t,k)+1)
  with np.errstate(divide='ignore'):
   dp[:,j]=np.logaddexp(dp[:,j]+np.log((t-j)/t),dp[:,j-1]+np.log(j/t)+logs[:,t-1,None])
 return max(0.,float(dp[:,k].max()))
def tune(w,B,m):
 n=len(w);k=n//2;mx=max(w);coef=harmonic(n,k);base=np.sqrt(8*LOGCAP/(B*coef*mx**2));cache={}
 if m=='empirical_bernstein_fixed_forecast':
  gamma=w.mean()/(2*mx);proxy=np.mean((w/(2*mx)-gamma)**2)+np.mean((w/mx)**2)/12;limit=k/(n*mx)
  def val(x):
   l=float(np.exp(x));th=l*n/k*mx*(n-k)/(n-np.arange(1,k+1));out=(B*float(np.sum(-np.log1p(-th)-th))*proxy+LOGCAP)/l;cache[l]=out;return out
  for s in [.5,.75,1,1.25,1.5,2]:val(np.log(min(base*s,.95*limit)))
  minimize_scalar(val,bounds=(np.log(min(base/1000,limit/1000)),np.log(.95*limit)),method='bounded',options={'xatol':1e-8,'maxiter':64})
  l=min(cache,key=cache.get);return {'lambda':l,'gamma':gamma,'theta':l*n/k*mx*(n-k)/(n-np.arange(1,k+1))}
 def moment(l):
  hm=l*l*coef*mx**2/8
  if m=='harmonic_martingale':return hm
  if m=='quota':return qlog(w,k,l)
  product=np.sum(np.logaddexp(l*w,-l*w)-np.log(2))
  return min(hm,product) if m=='weight_sensitive_hybrid' else product
 def val(x):
  l=float(np.exp(x));out=(B*moment(l)+LOGCAP)/l;cache[l]=out;return out
 for s in [.5,.75,1,1.25,1.5,2]:val(np.log(base*s))
 minimize_scalar(val,bounds=(np.log(base/1000),np.log(base*100)),method='bounded',options={'xatol':1e-8,'maxiter':64})
 l=min(cache,key=cache.get);return {'lambda':l,'radius':cache[l]/(B*w.sum())}
def main():
 start=time.time();cache={};rows=[];pairs=[];draws=[];bias=[];settings=[]
 for case,(n,B,shape,eff,report) in enumerate(itertools.product([8,24,64],[8,32],['equal','concentrated'],[-160,0,40,160],['complete','coarse_interval','assignment_dependent'])):
  w=np.ones(n,dtype=np.int64)
  if shape=='concentrated':w[-1]=10
  key=(n,B,shape);k=n//2;total=B*int(w.sum())
  if key not in cache:
   cache[key]={m:tune(w,B,m) for m in METHODS[:5]}
   settings.extend({'n':n,'blocks':B,'shape':shape,'method':m,**{kk:(vv.tolist() if isinstance(vv,np.ndarray) else vv) for kk,vv in v.items()}} for m,v in cache[key].items())
  rng=np.random.default_rng(np.random.SeedSequence([SEED,case]));org=np.random.default_rng(np.random.SeedSequence([SEED,case,1]));idx=np.empty((2,R,B,k),int)
  for r in range(R):
   tr=[rng.choice(n,k,replace=False).tolist() for _ in range(B)]
   co=[np.flatnonzero(~np.isin(np.arange(n),x)).tolist() for x in tr]
   idx[0,r]=[org.permutation(x) for x in co];idx[1,r]=[org.permutation(x) for x in tr]
  base=200+5*((np.arange(B)[:,None]*17+np.arange(n)[None,:]*37)%101);pot=np.stack([base,base+eff])
  selected=pot[np.arange(2)[:,None,None,None],np.arange(B)[None,None,:,None],idx]
  def endpoints(y,a):
   if report=='complete':return y,y
   if report=='coarse_interval':return (y//200)*200,np.minimum(1000,(y//200)*200+200)
   seen=(y<=500) if a==0 else (y>=500);return np.where(seen,y,0),np.where(seen,y,1000)
  ls=[];hs=[];mid=[]
  for a in range(2):
   l,h=endpoints(selected[a],a);ls.append(l);hs.append(h);l,h=endpoints(pot[a],a);mid.append(float(np.sum((l+h)*w)/(2000*total)))
  lo=np.array(ls);hi=np.array(hs);sw=w[idx];nl=(sw*lo).sum(axis=(2,3));nh=(sw*hi).sum(axis=(2,3));mass=sw.sum(axis=(2,3))
  ll=nl/(1000*total);hh=(nh+1000*(total-mass))/(1000*total)
  probabilities={};cert={};cov={};fallback={}
  for m in METHODS[:5]:
   par=cache[key][m]
   if m=='empirical_bernstein_fixed_forecast':
    lam=par['lambda'];th=par['theta'];rho=(-np.log1p(-th)-th)[None,None,None,:];mx=max(w);gamma=par['gamma'];a=lam*n/k*mx
    xl=sw*lo/(1000*mx);xh=sw*hi/(1000*mx);cl=rho*(xl-gamma)**2;ch=rho*(xh-gamma)**2
    gp=np.minimum(a*xl-cl,a*xh-ch).sum(axis=(2,3));gm=np.minimum(-a*xl-cl,-a*xh-ch).sum(axis=(2,3))
    L=np.maximum(ll,(gp-LOGCAP)/(lam*total));H=np.minimum(hh,(LOGCAP-gm)/(lam*total))
   else:
    radius=par['radius'];L=np.maximum(ll,2*nl/(1000*total)-radius);H=np.minimum(hh,2*nh/(1000*total)+radius)
   mu=(pot*w[None,None,:]).sum(axis=(1,2))/(1000*total);cov[m]=((L<=mu[:,None])&(H>=mu[:,None])).all(axis=0)
   fail=(L>H).any(axis=0);L[:,fail]=ll[:,fail];H[:,fail]=hh[:,fail];fallback[m]=fail
   U=np.maximum(0.,H[1]-L[0]);D=np.maximum(0.,H[0]-L[1]);q=np.divide(U,U+D,out=np.full(R,.5),where=(U+D)>0)
   q=np.floor(q*1000000+.5)/1000000;probabilities[m]=q;cert[m]=np.maximum((1-q)*U,q*D)
  probabilities['no_learning_half']=np.full(R,.5);s=nl+nh;probabilities['empirical_best_midpoint']=np.where(s[1]>s[0],1.,np.where(s[1]<s[0],0.,.5))
  actual={m:(-eff/1000*q if eff<0 else eff/1000*(1-q)) for m,q in probabilities.items()}
  fields={'case':case,'n':n,'blocks':B,'weight_shape':shape,'effect_thousandths':eff,'reporting':report,'repetitions':R}
  for m,x in actual.items():
   rows.append({**fields,'method':m,'mean_actual_regret':x.mean(),'mc_standard_error':x.std(ddof=1)/np.sqrt(R),**({'mean_certificate':cert[m].mean(),'count_le_010':int((cert[m]<=.1).sum()),'coverage':int(cov[m].sum()),'fallbacks':int(fallback[m].sum())} if m in cert else {})})
  for a,b in itertools.combinations(METHODS,2):
   x=actual[a]-actual[b];pairs.append({**fields,'first_method':a,'second_method':b,'mean_regret_difference':x.mean(),'paired_mc_standard_error':x.std(ddof=1)/np.sqrt(R)})
  draws.append(pd.DataFrame({'case':case,'repetition':np.arange(R),**actual}));bias.append({**fields,'population_midpoint_difference':mid[1]-mid[0]})
  if case%24==23:print('Completed',case+1,flush=True)
 df=pd.DataFrame(rows);pp=pd.DataFrame(pairs);df.to_csv(ROOT/'synthetic_results.csv',index=False);pp.to_csv(ROOT/'synthetic_pairs.csv',index=False)
 pd.concat(draws).to_csv(ROOT/'synthetic_draws.csv',index=False);pd.DataFrame(bias).to_csv(ROOT/'midpoint_bias.csv',index=False);(ROOT/'synthetic_settings.json').write_text(json.dumps(settings,indent=2))
 ag=[]
 for reporting in ['complete','coarse_interval','assignment_dependent']:
  p=pp[(pp.reporting==reporting)&(pp.first_method=='quota')&(pp.second_method=='empirical_bernstein_fixed_forecast')]
  ag.append({'reporting':reporting,'quota_minus_EB':p.mean_regret_difference.mean(),'paired_mc_se':np.sqrt((p.paired_mc_standard_error**2).sum())/len(p)})
 summary={'scope':'Independent floating-point reconstruction of synthetic catalogue; not directed certification or field-data replication. All144 cells,256 draws/cell,seven rules.','seconds':time.time()-start,'aggregates':ag,'regret_means':df.groupby(['reporting','method']).mean_actual_regret.mean().reset_index().to_dict('records')}
 (ROOT/'synthetic_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
