# Independent eighth-review calculations

This bundle concerns tag v0.8.0, commit 50c96dcea50b5aac25e5beb0912f54ff26e1b47b.

The synthetic catalogue was independently reimplemented in ordinary floating point, using its declared populations, seed, method formulas and rule definitions. All144 cells,256 assignments per cell,and seven rules were evaluated. These are NOT Rwanda household data. The program does not import the author modules and does not reproduce their directed interval or exact per-draw certificate validators.

Twelve published effect-specific quota-minus-empirical-Bernstein means/SEs and 32 published paired draws were checked against the reconstruction. Original aggregate and draw fields were transcribed for these comparisons; no claim of authenticating an entire original receipt is made.

Only canonical costs.csv was reconstructed from its public gzip/base64 alias; both the part and decompressed SHA256 match the manifest. Other field inputs were not reconstructed. No empirical constants, household/child analysis, master, Stata, field-region membership or support certificate chain was executed. No PDF was retrieved or inspected. Hosted metadata was read, not the artifact archive.

Run independent_designs.py and then verify_summaries.py to regenerate the synthetic comparison. Run rebuild_cost.py to repeat the small-file byte reconstruction.
