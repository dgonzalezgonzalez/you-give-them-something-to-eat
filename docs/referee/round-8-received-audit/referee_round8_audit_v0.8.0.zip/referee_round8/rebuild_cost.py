from pathlib import Path
import base64,gzip,hashlib,json
p=Path(__file__).parent
text='H4sIAAAAAAAC/02QzW7bQAyE736WxYL/XN4L5NIeezYUZ5su6liCrLTo25eSW6R7Izn8dobb2qftrd+2cpnv2/m53/q3cRnT+rvcv09rP08/+7r1lxy/Ldcx3S793K/jdTxf+/2x86/8X7LMy/t12s12sZ8e2g+6tPT+PG+jnUuKFgbR4QxtwLV4HjETShLD0MQp0C3giRVmjvkkuUQmyOoKrJRoVaBIAS8gZ2ePp0/z7/6Wswq4I43YSyYWw1RqSlwCy3KVd0RgQL0QErDMGhBnv9VAvSABnEgv4yXgog1x38NH0Cj4AR4UyqhH3U8PGqhFGXP0wLLDvq6LOkNRatQosj2dDuK2ZwQjGyPi5UEgpo9rLEKoKmQFLJqQSTOAX6kndbXXjTjqkTkkYIPYiBzItCyWxS9Cmuac5Yd6erMeWCWViKqGmpqgfD0B+BYRxgTAgAA\n'
# Correct the duplicated transcription token before checking the public hash.
text=text.replace('12s12s','12s')
a=hashlib.sha256(text.encode()).hexdigest()
assert a=='cec4a7d64719e210705fb637074afad65f619a9e9f95104136f96ae1467b3002',a
raw=gzip.decompress(base64.b64decode(text));b=hashlib.sha256(raw).hexdigest()
assert b=='5a4ef59498b23cb337b9060ae76e793d50229284a49f9af545f55b0e99ff09bc',b
p.joinpath('costs.csv').write_bytes(raw)
p.joinpath('cost_reconstruction.json').write_text(json.dumps({'part_sha256':a,'original_sha256':b,'original_bytes':len(raw),'scope':'Only canonical costs.csv reconstructed; not household or child microdata'},indent=2))
print(raw.decode())
