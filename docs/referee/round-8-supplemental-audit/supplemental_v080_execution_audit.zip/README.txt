Supplemental execution for v0.8.0, frozen commit 50c96dcea50b5aac25e5beb0912f54ff26e1b47b. Existing Reject recommendation unchanged.

The full household input was NOT recovered. Two of 36 compressed text parts were verified. The CSV included is an explicitly incomplete gzip prefix, not a replacement scientific input.

The quota replay uses the actual downloaded hosted ZIP, whose local SHA256 matched the published artifact digest. The ZIP contains outputs, not canonical microdata. Exact rational population constraints and arm means, directed exponential memberships, lower duals, and upper tangent/LP-dual bounds were replayed conditional on those output model constants. Hybrid chains and empirical model regeneration were not performed.

The independent script requires the hosted output JSON files named in its source. Obtain them from artifact11155805912 and extract to hosted_outputs relative to this directory; the large author-output files are not repeated in this small audit bundle.

The initial replay attempts had corrected local parsing errors for dictionary-valued string allocation numerators and denominator; these were referee-script errors, not manuscript discrepancies. Corrupted manual copies of two additional base64 parts were excluded and not used.
