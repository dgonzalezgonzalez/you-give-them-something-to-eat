"""Independent exact/Decimal replay of the hosted quota-region receipts.
This does NOT construct empirical constants from microdata.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D, localcontext, ROUND_FLOOR, ROUND_CEILING
import json, hashlib, time
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'hosted_outputs'
PREC=110
ARMS=['Control','Gikuriro','Lower','Middle','Upper','Large']

def frac(x):
    return F(x) if isinstance(x,(str,int,F)) else F.from_float(float(x))

def dec(x, mode):
    x=frac(x)
    with localcontext() as c:
        c.prec=PREC;c.rounding=mode
        return D(x.numerator)/D(x.denominator)

def binary(a,b,op,mode):
    with localcontext() as c:
        c.prec=PREC;c.rounding=mode
        return op(a,b)

def addlo(a,b):return binary(a,b,lambda x,y:x+y,ROUND_FLOOR)
def addhi(a,b):return binary(a,b,lambda x,y:x+y,ROUND_CEILING)
def mullo(a,b):return binary(a,b,lambda x,y:x*y,ROUND_FLOOR)
def mulhi(a,b):return binary(a,b,lambda x,y:x*y,ROUND_CEILING)

def exp_interval_fraction(x):
    with localcontext() as c:
        c.prec=PREC
        low=dec(x,ROUND_FLOOR).exp().next_minus()
        high=dec(x,ROUND_CEILING).exp().next_plus()
    return low,high

def interval_times_fraction(interval,x):
    lo,hi=interval;x=frac(x)
    if x>=0:return mullo(lo,dec(x,ROUND_FLOOR)),mulhi(hi,dec(x,ROUND_CEILING))
    return mullo(hi,dec(x,ROUND_FLOOR)),mulhi(lo,dec(x,ROUND_CEILING))

def exact_dot(a,b):return sum((frac(x)*frac(y) for x,y in zip(a,b)),F(0))

def event_upper(models, population):
    upper=D(0)
    for model,p in zip(models,population):
        assert len(p)==13 and sum(p)==1
        assert all(x>=frac(f) for x,f in zip(p,model['bin_floors']))
        assert all(exact_dot(row,p)<=frac(b) for row,b in zip(model['A'],model['b']))
        for row,intercept in zip(model['C'],model['intercept']):
            arg=exact_dot(row,p)+frac(intercept)
            upper=addhi(upper,exp_interval_fraction(arg)[1])
    return upper

def vertices(cost,budget,labels):
    arms=list(cost);ans={}
    for i,a in enumerate(arms):
        if cost[a]<=budget:
            v=[F(0)]*len(arms);v[i]=1;ans[a]=v
    for i,a in enumerate(arms):
        for j,b in enumerate(arms):
            if cost[a]<budget<cost[b]:
                p=(budget-cost[a])/(cost[b]-cost[a]);v=[F(0)]*len(arms);v[i]=1-p;v[j]=p
                ans[a+'+'+b]=v
    return [ans[a] for a in labels]

def lower_replay(receipt, models, vs, costs, budget):
    populations=[[[F(x) for x in row] for row in pop] for pop in receipt['exact_feasible_populations']]
    event_values=[]
    for pop in populations:
        u=event_upper(models,pop);assert u<=5520;event_values.append(str(u))
    objective=receipt['objective']
    score=[F(s) if objective=='mean' else -F(max(6-s,0),6) for s in range(13)]
    means=[[exact_dot(p,score) for p in pop] for pop in populations]
    assert means==[[F(x) for x in row] for row in receipt['exact_arm_means']]
    dual=receipt['dual'];w=list(map(F,dual['probabilities']));eta=F(dual['nonnegative_cost_multiplier']);idx=dual['source_indices']
    assert len(w)==len(idx) and min(w)>=0 and sum(w)==1 and eta>=0
    av=[sum((weight*means[m][j] for weight,(m,r) in zip(w,idx)),F(0)) for j in range(6)]
    constant=sum((weight*exact_dot(vs[r],means[m]) for weight,(m,r) in zip(w,idx)),F(0))
    lower=constant-eta*budget-max(x-eta*c for x,c in zip(av,costs))
    assert lower==F(dual['exact_dual_lower'])
    assert max(F(0),lower)==F(receipt['exact_lower'])
    return {'objective':objective,'populations':len(populations),'membership_all_pass':True,'event_upper_values':event_values,'exact_means_match':True,'exact_dual_match':True,'dual_lower_fraction':str(lower),'lower_float':float(lower)}

def support_replay(model, arm, tau):
    """Enclosed tangent plus exact feasible LP dual, with an independent error bound."""
    x=list(map(frac,arm['candidate']));direction=list(map(frac,arm['direction']));g=list(map(frac,arm['tangent_gradient']))
    fl=fh=D(0);derivs=[(D(0),D(0)) for _ in x]
    for row,intercept in zip(model['C'],model['intercept']):
        el,eh=exp_interval_fraction(exact_dot(row,x)+frac(intercept))
        fl=addlo(fl,el);fh=addhi(fh,eh)
        for j,coef in enumerate(row):
            dl,dh=interval_times_fraction((el,eh),coef)
            old=derivs[j];derivs[j]=(addlo(old[0],dl),addhi(old[1],dh))
    t=tau/F(5520)
    hf=interval_times_fraction((fl,fh),t)[0]
    hf=addlo(hf,dec(exact_dot(direction,x),ROUND_CEILING).copy_negate())
    error=D(0)
    for j,(dl,dh) in enumerate(derivs):
        dl,dh=interval_times_fraction((dl,dh),t)
        dl=addlo(dl,dec(direction[j],ROUND_CEILING).copy_negate());dh=addhi(dh,dec(direction[j],ROUND_FLOOR).copy_negate())
        # Fraction conversion here is exact for these finite Decimal bounds.
        e=max(abs(g[j]-F(dl)),abs(g[j]-F(dh)))
        distance=max(abs(x[j]),abs(1-x[j]))
        error=addhi(error,dec(e*distance,ROUND_CEILING))
    dual=arm['LP_dual'];ell=list(map(frac,dual['nonpositive_multipliers']));zeta=F(dual['equality_multiplier'])
    A=[[frac(a) for a in row] for row in model['A']];b=list(map(frac,model['b']));f=list(map(frac,model['bin_floors']))
    assert all(v<=0 for v in ell)
    slacks=[g[j]-sum((ell[i]*A[i][j] for i in range(len(ell))),F(0))-zeta for j in range(13)]
    assert min(slacks)>=0
    lp=exact_dot(g,f)+sum((l*(bi-exact_dot(row,f)) for l,bi,row in zip(ell,b,A)),F(0))+zeta*(1-sum(f))
    lower=addlo(hf,dec(lp-exact_dot(g,x),ROUND_FLOOR));lower=addlo(lower,error.copy_negate())
    upper=lower.copy_negate()
    return upper, {'exact_lp_dual_feasible':True,'minimum_exact_dual_slack':str(min(slacks)),'enclosed_tangent_error_upper':str(error),'support_upper':str(upper)}

def upper_replay(scenario,models,vs):
    q=[F(int(scenario['chosen_allocation_numerators'][a]),int(scenario['chosen_allocation_denominator'])) for a in ARMS]
    assert min(q)>=0 and sum(q)==1
    score=[F(s) if scenario['objective']=='mean' else -F(max(6-s,0),6) for s in range(13)]
    results=[]
    for comp,v in zip(scenario['comparators'],vs):
        tau=frac(comp['tau']);assert tau>=0
        upper=dec(tau,ROUND_CEILING);correction=F(0);ars=[]
        for j,(m,a) in enumerate(zip(models,comp['arms'])):
            exact_dir=[(v[j]-q[j])*s for s in score]
            correction+=max(abs(d-frac(dd)) for d,dd in zip(exact_dir,a['direction']))
            up,ar=support_replay(m,a,tau);upper=addhi(upper,up);ars.append(ar)
        upper=addhi(upper,dec(correction,ROUND_CEILING))
        results.append({'comparator':comp['comparator'],'recomputed_upper':str(upper),'published_upper':comp['support_upper'],'difference_float':float(upper)-comp['support_upper'],'exact_direction_rounding':str(correction),'arms':ars})
    maximum=max(D(x['recomputed_upper']) for x in results)
    with localcontext() as ctx:
        ctx.prec=PREC;ctx.rounding=ROUND_CEILING
        display=str(maximum.quantize(D('.001')))
    assert float(display)==float(scenario['reported_conservative_loss_upper'])
    return {'objective':scenario['objective'],'all_54_arm_duals_pass':True,'recomputed_upper':str(maximum),'published_upper':scenario['conditional_loss_upper'],'upward_three_decimal_display':display,'comparators':results}

def main():
    start=time.time()
    q=json.loads((OUT/'quota-loss-bound.json').read_text());reg=json.loads((OUT/'regional-minimax-brackets.json').read_text());policy=json.loads((OUT/'policies.json').read_text())
    models=q['models'];arms=[m['arm'] for m in models]
    costs={a:frac(policy['costs'][a]) for a in arms};budget=frac(policy['budget'])
    labels=[r['comparator'] for r in q['scenarios'][0]['comparators']];vs=vertices(costs,budget,labels)
    assert all(exact_dot(v,costs.values())<=budget and sum(v)==1 for v in vs)
    lows=[];ups=[]
    for objective in ['mean','shortfall_6']:
        receipt=next(r for r in reg['receipts'] if r['method']=='quota' and r['bin_floors'] and r['objective']==objective)
        lows.append(lower_replay(receipt,models,vs,list(costs.values()),budget))
        scenario=next(s for s in q['scenarios'] if s['objective']==objective)
        qshare=[F(int(scenario['chosen_allocation_numerators'][a]),int(scenario['chosen_allocation_denominator'])) for a in ARMS]
        assert exact_dot(qshare,costs.values())<=budget
        ups.append(upper_replay(scenario,models,vs))
        print(objective, lows[-1]['lower_float'],ups[-1]['upward_three_decimal_display'],flush=True)
    result={'scope':'Independent quota-region membership, exact means, finite-adversary lower-dual and outward tangent/LP-dual upper replay from the locally downloaded and hash-verified AUTHOR HOSTED OUTPUTS. Not empirical constant generation or household/child replication. Hybrid membership/upper chain not replayed.','precision':PREC,'lowers':lows,'uppers':ups,'seconds':time.time()-start}
    (ROOT/'quota_chain_replay.json').write_text(json.dumps(result,indent=2))
if __name__=='__main__':main()
